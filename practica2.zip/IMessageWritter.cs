﻿
namespace Practice2
{
    interface IMessageWritter
    {
        string WriteMessage(string customMessage);
    }
}

//ese método debe existir en cualquier clase que decida implementar la interfaz.